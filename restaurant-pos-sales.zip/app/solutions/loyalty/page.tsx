"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Heart, Star, Users, Wallet } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LoyaltyROIChart } from "@/components/loyalty-roi-chart"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"

export default function LoyaltySolution() {
  const [activeTab, setActiveTab] = useState("features")

  const [monthlyCustomers, setMonthlyCustomers] = useState(1500)
  const [averageCheck, setAverageCheck] = useState(42)
  const [returnRate, setReturnRate] = useState(22)
  const [loyaltyEnrollment, setLoyaltyEnrollment] = useState(35)
  const [loyaltyCalculated, setLoyaltyCalculated] = useState(false)

  // Calculated values
  const loyaltyReturnRate = Math.min(returnRate * 2.2, 100) // Loyalty members return 2.2x more often
  const loyaltyCheckSize = averageCheck * 1.39 // Loyalty members spend 39% more
  const currentRevenue = monthlyCustomers * averageCheck
  const nonLoyaltyCustomers = monthlyCustomers * (1 - loyaltyEnrollment / 100)
  const loyaltyCustomers = monthlyCustomers * (loyaltyEnrollment / 100)
  const projectedRevenue = nonLoyaltyCustomers * averageCheck + loyaltyCustomers * loyaltyCheckSize
  const monthlyIncrease = projectedRevenue - currentRevenue
  const annualIncrease = monthlyIncrease * 12
  const revenueGrowth = (monthlyIncrease / currentRevenue) * 100
  const loyaltyROI = (monthlyIncrease / 199) * 100 // $199 is the monthly subscription cost

  const calculateLoyaltyROI = () => {
    setLoyaltyCalculated(true)
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center border-b">
        <Link className="flex items-center justify-center" href="/">
          <ArrowLeft className="mr-2 h-4 w-4" />
          <span className="font-bold text-xl">SpotOn</span>
        </Link>
      </header>
      <main className="flex-1 py-6 md:py-10">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col space-y-6">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter">SpotOn Loyalty</h1>
              <p className="text-muted-foreground">
                Build a loyal customer base and increase repeat business with our customizable loyalty program
              </p>
            </div>

            <Tabs defaultValue="features" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="features">Features</TabsTrigger>
                <TabsTrigger value="benefits">Benefits</TabsTrigger>
                <TabsTrigger value="roi">ROI Calculator</TabsTrigger>
              </TabsList>

              <TabsContent value="features" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card>
                    <CardHeader>
                      <Heart className="h-6 w-6 mb-2 text-primary" />
                      <CardTitle>Customizable Rewards</CardTitle>
                      <CardDescription>
                        Create a loyalty program that fits your restaurant's unique brand and customer base
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Points-based or visit-based rewards</li>
                        <li>Birthday rewards and special occasions</li>
                        <li>Tiered loyalty levels with increasing benefits</li>
                        <li>Custom rewards for specific menu items</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <Users className="h-6 w-6 mb-2 text-primary" />
                      <CardTitle>Customer Engagement</CardTitle>
                      <CardDescription>
                        Keep customers engaged with your brand through personalized communication
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Automated email and SMS marketing</li>
                        <li>Personalized offers based on purchase history</li>
                        <li>Feedback collection and review generation</li>
                        <li>Special event invitations for loyal customers</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <Star className="h-6 w-6 mb-2 text-primary" />
                      <CardTitle>Easy Customer Experience</CardTitle>
                      <CardDescription>Frictionless loyalty experience that customers love to use</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Phone number or email sign-up</li>
                        <li>No physical cards required</li>
                        <li>Automatic point tracking with every purchase</li>
                        <li>Mobile app for customers to track rewards</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Seamless Integration</CardTitle>
                    <CardDescription>
                      SpotOn Loyalty integrates directly with your POS system for a unified experience
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <h3 className="text-lg font-medium mb-2">For Your Staff</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>One-touch loyalty enrollment at checkout</li>
                          <li>Automatic point calculation</li>
                          <li>Reward redemption directly in POS</li>
                          <li>Customer profiles with purchase history</li>
                        </ul>
                      </div>
                      <div>
                        <h3 className="text-lg font-medium mb-2">For Your Customers</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>Simple sign-up process</li>
                          <li>Real-time points balance updates</li>
                          <li>Mobile notifications for available rewards</li>
                          <li>Digital receipts with loyalty status</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={() => setActiveTab("benefits")}>See How Loyalty Drives Revenue</Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="benefits" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>The Impact of Customer Loyalty</CardTitle>
                    <CardDescription>
                      Loyalty programs drive significant business growth through repeat customers
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-6 md:grid-cols-3">
                      <div className="flex flex-col items-center text-center">
                        <div className="text-4xl font-bold text-primary mb-2">67%</div>
                        <p className="text-sm text-muted-foreground">
                          Increase in customer retention for restaurants with loyalty programs
                        </p>
                      </div>
                      <div className="flex flex-col items-center text-center">
                        <div className="text-4xl font-bold text-primary mb-2">39%</div>
                        <p className="text-sm text-muted-foreground">
                          Higher average check size from loyalty program members
                        </p>
                      </div>
                      <div className="flex flex-col items-center text-center">
                        <div className="text-4xl font-bold text-primary mb-2">12x</div>
                        <p className="text-sm text-muted-foreground">
                          More cost-effective to retain existing customers than acquire new ones
                        </p>
                      </div>
                    </div>

                    <div className="mt-8 space-y-4">
                      <h3 className="text-lg font-medium">Key Benefits for Your Restaurant:</h3>
                      <div className="grid gap-4 md:grid-cols-2">
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Increased Customer Frequency</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm">
                              Loyalty members visit 2.5x more often than non-members, driving consistent revenue even
                              during slow periods.
                            </p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Higher Average Spend</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm">
                              Loyalty members spend 39% more per visit on average, adding directly to your bottom line.
                            </p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Valuable Customer Data</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm">
                              Gain insights into customer preferences and behaviors to optimize your menu and marketing.
                            </p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Reduced Marketing Costs</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm">
                              Direct communication with your customer base reduces reliance on expensive third-party
                              platforms.
                            </p>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={() => setActiveTab("roi")}>Calculate Your Loyalty ROI</Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="roi" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Loyalty Program ROI Calculator</CardTitle>
                    <CardDescription>See the potential financial impact of implementing SpotOn Loyalty</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <form className="space-y-6">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="monthly-customers">Monthly Customers</Label>
                          <Input
                            id="monthly-customers"
                            type="number"
                            value={monthlyCustomers}
                            onChange={(e) => setMonthlyCustomers(Number(e.target.value))}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="average-check">Average Check Size ($)</Label>
                          <Input
                            id="average-check"
                            type="number"
                            step="0.01"
                            value={averageCheck}
                            onChange={(e) => setAverageCheck(Number(e.target.value))}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="return-rate">Current Return Rate (%)</Label>
                          <Input
                            id="return-rate"
                            type="number"
                            step="0.1"
                            value={returnRate}
                            onChange={(e) => setReturnRate(Number(e.target.value))}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="loyalty-enrollment">Expected Loyalty Enrollment (%)</Label>
                          <Input
                            id="loyalty-enrollment"
                            type="number"
                            step="0.1"
                            value={loyaltyEnrollment}
                            onChange={(e) => setLoyaltyEnrollment(Number(e.target.value))}
                          />
                        </div>
                      </div>

                      <Button type="button" className="w-full" onClick={calculateLoyaltyROI}>
                        Calculate Loyalty ROI
                      </Button>
                    </form>

                    {loyaltyCalculated && (
                      <>
                        <div className="grid gap-4 md:grid-cols-2">
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-base">Current Business Metrics</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="space-y-4">
                                <div>
                                  <div className="flex justify-between">
                                    <span className="font-medium">Monthly Customers:</span>
                                    <span>{monthlyCustomers}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="font-medium">Average Check Size:</span>
                                    <span>${averageCheck.toFixed(2)}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="font-medium">Customer Return Rate:</span>
                                    <span>{returnRate}%</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="font-medium">Monthly Revenue:</span>
                                    <span>${currentRevenue.toFixed(2)}</span>
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>

                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-base">With SpotOn Loyalty</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="space-y-4">
                                <div>
                                  <div className="flex justify-between">
                                    <span className="font-medium">Loyalty Enrollment Rate:</span>
                                    <span>{loyaltyEnrollment}%</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="font-medium">Loyalty Member Return Rate:</span>
                                    <span>{loyaltyReturnRate}%</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="font-medium">Loyalty Member Check Size:</span>
                                    <span>${loyaltyCheckSize.toFixed(2)}</span>
                                  </div>
                                  <div className="flex justify-between font-bold text-primary">
                                    <span>Projected Monthly Revenue:</span>
                                    <span>${projectedRevenue.toFixed(2)}</span>
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </div>

                        <div className="h-[300px] w-full">
                          <LoyaltyROIChart currentRevenue={currentRevenue} projectedRevenue={projectedRevenue} />
                        </div>

                        <div className="grid gap-4 md:grid-cols-2">
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-base">Financial Impact</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="space-y-4">
                                <div>
                                  <div className="text-3xl font-bold text-primary">${monthlyIncrease.toFixed(2)}</div>
                                  <p className="text-sm text-muted-foreground">Monthly Revenue Increase</p>
                                </div>
                                <div>
                                  <div className="text-3xl font-bold text-primary">${annualIncrease.toFixed(2)}</div>
                                  <p className="text-sm text-muted-foreground">Annual Revenue Increase</p>
                                </div>
                                <div>
                                  <div className="text-xl font-bold">{revenueGrowth.toFixed(1)}%</div>
                                  <p className="text-sm text-muted-foreground">Revenue Growth</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>

                          <Card>
                            <CardHeader>
                              <CardTitle className="text-base">Implementation</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="space-y-4">
                                <div>
                                  <div className="text-xl font-bold">$199/month</div>
                                  <p className="text-sm text-muted-foreground">SpotOn Loyalty Subscription</p>
                                </div>
                                <div>
                                  <div className="text-xl font-bold">1-2 days</div>
                                  <p className="text-sm text-muted-foreground">Setup and Training Time</p>
                                </div>
                                <div>
                                  <div className="text-xl font-bold text-primary">{loyaltyROI.toFixed(1)}%</div>
                                  <p className="text-sm text-muted-foreground">ROI on Monthly Subscription</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </div>
                      </>
                    )}
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={() => setActiveTab("features")}>
                      Back to Features
                    </Button>
                    <Button>
                      <Wallet className="mr-2 h-4 w-4" />
                      Schedule Demo
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  )
}

