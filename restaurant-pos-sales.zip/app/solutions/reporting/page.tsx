"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, BarChart3, LineChart, PieChart, Wallet } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ReportingROIChart } from "@/components/reporting-roi-chart"

export default function ReportingSolution() {
  const [activeTab, setActiveTab] = useState("features")

  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center border-b">
        <Link className="flex items-center justify-center" href="/">
          <ArrowLeft className="mr-2 h-4 w-4" />
          <span className="font-bold text-xl">SpotOn Solutions</span>
        </Link>
      </header>
      <main className="flex-1 py-6 md:py-10">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col space-y-6">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter">SpotOn Reporting</h1>
              <p className="text-muted-foreground">
                Gain powerful insights with real-time analytics and customizable reports to optimize your operations
              </p>
            </div>

            <Tabs defaultValue="features" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="features">Features</TabsTrigger>
                <TabsTrigger value="benefits">Benefits</TabsTrigger>
                <TabsTrigger value="roi">ROI Calculator</TabsTrigger>
              </TabsList>

              <TabsContent value="features" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card>
                    <CardHeader>
                      <BarChart3 className="h-6 w-6 mb-2 text-primary" />
                      <CardTitle>Real-Time Dashboards</CardTitle>
                      <CardDescription>Access critical business metrics instantly from anywhere</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Sales performance by hour, day, week, month</li>
                        <li>Labor cost percentage in real-time</li>
                        <li>Food cost and inventory tracking</li>
                        <li>Mobile access to dashboards</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <LineChart className="h-6 w-6 mb-2 text-primary" />
                      <CardTitle>Custom Reports</CardTitle>
                      <CardDescription>
                        Build and schedule reports tailored to your specific business needs
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Menu item performance analysis</li>
                        <li>Server performance metrics</li>
                        <li>Comparative period reporting</li>
                        <li>Automated email delivery of reports</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <PieChart className="h-6 w-6 mb-2 text-primary" />
                      <CardTitle>Advanced Analytics</CardTitle>
                      <CardDescription>
                        Uncover insights that drive profitability and operational efficiency
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Customer behavior analysis</li>
                        <li>Menu engineering recommendations</li>
                        <li>Labor optimization insights</li>
                        <li>Predictive sales forecasting</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Comprehensive Reporting Suite</CardTitle>
                    <CardDescription>
                      SpotOn Reporting provides the insights you need to make data-driven decisions
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <h3 className="text-lg font-medium mb-2">Financial Reports</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>Daily sales summaries</li>
                          <li>Profit and loss statements</li>
                          <li>Cash flow analysis</li>
                          <li>Tax reporting</li>
                          <li>Credit card reconciliation</li>
                        </ul>
                      </div>
                      <div>
                        <h3 className="text-lg font-medium mb-2">Operational Reports</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>Labor scheduling and cost analysis</li>
                          <li>Inventory usage and waste tracking</li>
                          <li>Table turn time optimization</li>
                          <li>Menu item popularity and profitability</li>
                          <li>Server performance metrics</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={() => setActiveTab("benefits")}>See How Reporting Drives Profitability</Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="benefits" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>The Power of Data-Driven Decisions</CardTitle>
                    <CardDescription>
                      Restaurants using advanced reporting see significant improvements in profitability
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-6 md:grid-cols-3">
                      <div className="flex flex-col items-center text-center">
                        <div className="text-4xl font-bold text-primary mb-2">15%</div>
                        <p className="text-sm text-muted-foreground">
                          Average reduction in food costs through better inventory management
                        </p>
                      </div>
                      <div className="flex flex-col items-center text-center">
                        <div className="text-4xl font-bold text-primary mb-2">12%</div>
                        <p className="text-sm text-muted-foreground">
                          Decrease in labor costs through optimized scheduling
                        </p>
                      </div>
                      <div className="flex flex-col items-center text-center">
                        <div className="text-4xl font-bold text-primary mb-2">8%</div>
                        <p className="text-sm text-muted-foreground">
                          Increase in average check size through menu engineering
                        </p>
                      </div>
                    </div>

                    <div className="mt-8 space-y-4">
                      <h3 className="text-lg font-medium">Key Benefits for Your Restaurant:</h3>
                      <div className="grid gap-4 md:grid-cols-2">
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Identify Profit Leaks</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm">
                              Pinpoint areas of waste, theft, or inefficiency that are impacting your bottom line.
                            </p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Optimize Your Menu</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm">
                              Identify your most profitable items and strategically price and position them to maximize
                              sales.
                            </p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Staff More Efficiently</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm">
                              Schedule the right number of staff at the right times based on historical sales data.
                            </p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Make Better Business Decisions</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm">
                              Use data rather than gut feeling to guide important business decisions and investments.
                            </p>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={() => setActiveTab("roi")}>Calculate Your Reporting ROI</Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="roi" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Reporting ROI Calculator</CardTitle>
                    <CardDescription>
                      See the potential financial impact of implementing SpotOn Reporting
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid gap-4 md:grid-cols-2">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base">Current Business Metrics</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div>
                              <div className="flex justify-between">
                                <span className="font-medium">Monthly Revenue:</span>
                                <span>$85,000</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="font-medium">Food Cost Percentage:</span>
                                <span>32%</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="font-medium">Labor Cost Percentage:</span>
                                <span>30%</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="font-medium">Monthly Profit:</span>
                                <span>$15,300</span>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base">With SpotOn Reporting</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div>
                              <div className="flex justify-between">
                                <span className="font-medium">Optimized Food Cost:</span>
                                <span>27.2% (15% reduction)</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="font-medium">Optimized Labor Cost:</span>
                                <span>26.4% (12% reduction)</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="font-medium">Revenue Increase:</span>
                                <span>$6,800 (8% increase)</span>
                              </div>
                              <div className="flex justify-between font-bold text-primary">
                                <span>Projected Monthly Profit:</span>
                                <span>$28,764</span>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="h-[300px] w-full">
                      <ReportingROIChart />
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">Financial Impact</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div>
                              <div className="text-3xl font-bold text-primary">$13,464</div>
                              <p className="text-sm text-muted-foreground">Monthly Profit Increase</p>
                            </div>
                            <div>
                              <div className="text-3xl font-bold text-primary">$161,568</div>
                              <p className="text-sm text-muted-foreground">Annual Profit Increase</p>
                            </div>
                            <div>
                              <div className="text-xl font-bold">88%</div>
                              <p className="text-sm text-muted-foreground">Profit Growth</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">Implementation</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div>
                              <div className="text-xl font-bold">$149/month</div>
                              <p className="text-sm text-muted-foreground">SpotOn Reporting Subscription</p>
                            </div>
                            <div>
                              <div className="text-xl font-bold">1 day</div>
                              <p className="text-sm text-muted-foreground">Setup and Training Time</p>
                            </div>
                            <div>
                              <div className="text-xl font-bold text-primary">9,036%</div>
                              <p className="text-sm text-muted-foreground">ROI on Monthly Subscription</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={() => setActiveTab("features")}>
                      Back to Features
                    </Button>
                    <Button>
                      <Wallet className="mr-2 h-4 w-4" />
                      Schedule Demo
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  )
}

