"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, CreditCard, DollarSign, Percent, Wallet } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CashDiscountROIChart } from "@/components/cash-discount-roi-chart"

export default function CashDiscountSolution() {
  const [activeTab, setActiveTab] = useState("features")
  const [monthlyCardVolume, setMonthlyCardVolume] = useState(65000)
  const [currentProcessingRate, setCurrentProcessingRate] = useState(3.2)
  const [calculationPerformed, setCalculationPerformed] = useState(false)

  const handleCalculate = (e: React.FormEvent) => {
    e.preventDefault()
    setCalculationPerformed(true)
    setActiveTab("roi")
  }

  // Calculate current processing fees
  const currentFees = monthlyCardVolume * (currentProcessingRate / 100)

  // Calculate fees with cash discount program (typically around 0.5-1% effective rate)
  const discountedRate = 0.8 // 0.8% effective rate with cash discount
  const discountedFees = monthlyCardVolume * (discountedRate / 100)

  // Calculate savings
  const monthlySavings = currentFees - discountedFees
  const annualSavings = monthlySavings * 12

  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center border-b">
        <Link className="flex items-center justify-center" href="/">
          <ArrowLeft className="mr-2 h-4 w-4" />
          <span className="font-bold text-xl">SpotOn Solutions</span>
        </Link>
      </header>
      <main className="flex-1 py-6 md:py-10">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col space-y-6">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter">SpotOn Cash Discount</h1>
              <p className="text-muted-foreground">
                Reduce credit card processing fees with a compliant cash discount program
              </p>
            </div>

            <Tabs defaultValue="features" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="features">Features</TabsTrigger>
                <TabsTrigger value="calculator">Calculator</TabsTrigger>
                <TabsTrigger value="roi" disabled={!calculationPerformed}>
                  ROI Analysis
                </TabsTrigger>
              </TabsList>

              <TabsContent value="features" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card>
                    <CardHeader>
                      <DollarSign className="h-6 w-6 mb-2 text-primary" />
                      <CardTitle>Reduce Processing Costs</CardTitle>
                      <CardDescription>Significantly lower your credit card processing fees</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Reduce effective processing rate to as low as 0.8%</li>
                        <li>Save thousands in processing fees annually</li>
                        <li>Maintain revenue while reducing expenses</li>
                        <li>Improve cash flow immediately</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <Percent className="h-6 w-6 mb-2 text-primary" />
                      <CardTitle>Compliant Program</CardTitle>
                      <CardDescription>Fully compliant with card brand regulations and state laws</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Properly structured non-cash adjustment</li>
                        <li>Compliant signage and receipt language</li>
                        <li>Regular program updates as regulations change</li>
                        <li>Transparent customer communication</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CreditCard className="h-6 w-6 mb-2 text-primary" />
                      <CardTitle>Seamless Implementation</CardTitle>
                      <CardDescription>Easy to implement with minimal impact on operations</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Automatic application at checkout</li>
                        <li>Staff training and support materials</li>
                        <li>Customer-facing signage and explanations</li>
                        <li>No change to checkout flow</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>How Cash Discount Works</CardTitle>
                    <CardDescription>
                      A simple, transparent way to reduce processing costs while staying compliant
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="grid gap-4 md:grid-cols-3">
                        <div className="flex flex-col items-center text-center p-4 border rounded-lg">
                          <div className="text-xl font-bold mb-2">Step 1</div>
                          <p className="text-sm">Menu prices are set to include a small service fee (typically 3-4%)</p>
                        </div>
                        <div className="flex flex-col items-center text-center p-4 border rounded-lg">
                          <div className="text-xl font-bold mb-2">Step 2</div>
                          <p className="text-sm">
                            Customers who pay with cash receive a discount equal to the service fee
                          </p>
                        </div>
                        <div className="flex flex-col items-center text-center p-4 border rounded-lg">
                          <div className="text-xl font-bold mb-2">Step 3</div>
                          <p className="text-sm">
                            The service fee offsets most or all of your credit card processing costs
                          </p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h3 className="text-lg font-medium">Key Benefits:</h3>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>Fully compliant with card brand regulations</li>
                          <li>Transparent to customers with proper signage</li>
                          <li>Can reduce effective processing rate to as low as 0.8%</li>
                          <li>Encourages cash payments, further reducing processing volume</li>
                          <li>Implemented and supported by SpotOn's payment experts</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button onClick={() => setActiveTab("calculator")}>Calculate Your Potential Savings</Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="calculator" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Cash Discount Savings Calculator</CardTitle>
                    <CardDescription>See how much you could save with SpotOn's Cash Discount program</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleCalculate} className="space-y-6">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="monthly-volume">Monthly Credit Card Volume ($)</Label>
                          <Input
                            id="monthly-volume"
                            type="number"
                            value={monthlyCardVolume}
                            onChange={(e) => setMonthlyCardVolume(Number(e.target.value))}
                          />
                          <p className="text-xs text-muted-foreground">
                            Your average monthly sales processed through credit cards
                          </p>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="processing-rate">Current Processing Rate (%)</Label>
                          <Input
                            id="processing-rate"
                            type="number"
                            step="0.1"
                            value={currentProcessingRate}
                            onChange={(e) => setCurrentProcessingRate(Number(e.target.value))}
                          />
                          <p className="text-xs text-muted-foreground">
                            Your current effective rate (total fees divided by total volume)
                          </p>
                        </div>
                      </div>

                      <div className="grid gap-4 md:grid-cols-2">
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Current Monthly Fees</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="text-2xl font-bold">${currentFees.toFixed(2)}</div>
                            <p className="text-sm text-muted-foreground">
                              Based on {currentProcessingRate}% processing rate
                            </p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Estimated Monthly Savings</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="text-2xl font-bold text-primary">${monthlySavings.toFixed(2)}</div>
                            <p className="text-sm text-muted-foreground">With SpotOn Cash Discount program</p>
                          </CardContent>
                        </Card>
                      </div>

                      <Button type="submit" className="w-full">
                        Calculate Detailed ROI
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="roi" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Cash Discount ROI Analysis</CardTitle>
                    <CardDescription>
                      See the detailed financial impact of implementing SpotOn Cash Discount
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid gap-4 md:grid-cols-2">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base">Current Processing Costs</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div>
                              <div className="flex justify-between">
                                <span className="font-medium">Monthly Card Volume:</span>
                                <span>${monthlyCardVolume.toFixed(2)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="font-medium">Current Processing Rate:</span>
                                <span>{currentProcessingRate}%</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="font-medium">Monthly Processing Fees:</span>
                                <span>${currentFees.toFixed(2)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="font-medium">Annual Processing Fees:</span>
                                <span>${(currentFees * 12).toFixed(2)}</span>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base">With Cash Discount Program</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div>
                              <div className="flex justify-between">
                                <span className="font-medium">Effective Processing Rate:</span>
                                <span>0.8%</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="font-medium">Monthly Processing Fees:</span>
                                <span>${discountedFees.toFixed(2)}</span>
                              </div>
                              <div className="flex justify-between font-bold text-primary">
                                <span>Monthly Savings:</span>
                                <span>${monthlySavings.toFixed(2)}</span>
                              </div>
                              <div className="flex justify-between font-bold text-primary">
                                <span>Annual Savings:</span>
                                <span>${annualSavings.toFixed(2)}</span>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="h-[300px] w-full">
                      <CashDiscountROIChart currentFees={currentFees} discountedFees={discountedFees} />
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">5-Year Impact</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div>
                              <div className="text-3xl font-bold text-primary">${(annualSavings * 5).toFixed(2)}</div>
                              <p className="text-sm text-muted-foreground">Total 5-Year Savings</p>
                            </div>
                            <div>
                              <div className="text-xl font-bold">
                                {(((currentFees - discountedFees) / currentFees) * 100).toFixed(1)}%
                              </div>
                              <p className="text-sm text-muted-foreground">Reduction in Processing Costs</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">Implementation</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div>
                              <div className="text-xl font-bold">$0</div>
                              <p className="text-sm text-muted-foreground">Setup Fee</p>
                            </div>
                            <div>
                              <div className="text-xl font-bold">1 day</div>
                              <p className="text-sm text-muted-foreground">Implementation Time</p>
                            </div>
                            <div>
                              <div className="text-xl font-bold text-primary">Immediate</div>
                              <p className="text-sm text-muted-foreground">Time to First Savings</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={() => setActiveTab("calculator")}>
                      Back to Calculator
                    </Button>
                    <Button>
                      <Wallet className="mr-2 h-4 w-4" />
                      Schedule Demo
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  )
}

