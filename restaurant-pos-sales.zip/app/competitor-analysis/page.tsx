"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  ArrowRight,
  BarChart3,
  Check,
  CreditCard,
  Heart,
  MapPin,
  Phone,
  Search,
  Star,
  Timer,
  Wallet,
  X,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CompetitorReviewChart } from "@/components/competitor-review-chart"
import { MenuPriceComparison } from "@/components/menu-price-comparison"
import { Separator } from "@/components/ui/separator"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { ROIChart } from "@/components/roi-chart"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface BusinessInfo {
  name: string
  category: string
  rating: number
  reviewCount: number
  hours: string
  phone: string
  address: string
}

interface Competitor {
  id: string
  name: string
  rating: number
  vicinity: string
  types: string[]
  strengths: string[]
  weaknesses: string[]
}

export default function CompetitorAnalysis() {
  const [location, setLocation] = useState("")
  const [monthlyRevenue, setMonthlyRevenue] = useState(50000)
  const [searchPerformed, setSearchPerformed] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [businessInfo, setBusinessInfo] = useState<BusinessInfo>({
    name: "",
    category: "",
    rating: 0,
    reviewCount: 0,
    hours: "",
    phone: "",
    address: "",
  })
  const [competitors, setCompetitors] = useState<Record<string, Competitor>>({})

  // Simplified assumptions for ROI calculation
  const foodCost = 35 // % of revenue
  const laborCost = 30 // % of revenue
  const otherExpenses = 20 // % of revenue

  // Calculate current profit
  const currentProfit = monthlyRevenue * (1 - (foodCost + laborCost + otherExpenses) / 100)

  // Calculate projected profit with POS (assuming 5% revenue increase, 2% food cost reduction, 3% labor cost reduction)
  const projectedRevenue = monthlyRevenue * 1.05
  const projectedFoodCost = foodCost - 2
  const projectedLaborCost = laborCost - 3
  const projectedProfit = projectedRevenue * (1 - (projectedFoodCost + projectedLaborCost + otherExpenses) / 100)

  // Calculate ROI
  const monthlySavings = projectedProfit - currentProfit
  const annualSavings = monthlySavings * 12
  const posInvestment = 10000 // Assumed POS system cost
  const roi = (annualSavings / posInvestment) * 100
  const paybackPeriod = posInvestment / monthlySavings

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!location.trim()) return

    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/google-maps", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          address: location,
          type: "geocode",
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to fetch location data")
      }

      const data = await response.json()

      // Process business details
      if (data.businessDetails) {
        const businessDetails = data.businessDetails
        setBusinessInfo({
          name: businessDetails.name || location.split(",")[0].trim(),
          category: businessDetails.types?.[0]?.replace(/_/g, " ") || "Restaurant",
          rating: businessDetails.rating || 4.0,
          reviewCount: businessDetails.user_ratings_total || 100,
          hours: businessDetails.opening_hours?.weekday_text?.join(", ") || "Hours not available",
          phone: businessDetails.formatted_phone_number || "Phone not available",
          address: businessDetails.formatted_address || data.formattedAddress,
        })
      } else {
        // If no business details found, use the address as the business name
        setBusinessInfo({
          name: location.split(",")[0].trim(),
          category: "Restaurant",
          rating: 4.0,
          reviewCount: 100,
          hours: "Mon-Sat: 11:00 AM - 10:00 PM, Sun: 12:00 PM - 9:00 PM",
          phone: "Phone not available",
          address: data.formattedAddress,
        })
      }

      // Process competitors
      if (data.competitors && data.competitors.length > 0) {
        const competitorsObj: Record<string, Competitor> = {}

        // Generate random strengths and weaknesses for each competitor
        const possibleStrengths = [
          "Food quality",
          "Service",
          "Ambiance",
          "Value perception",
          "Menu variety",
          "Location",
        ]
        const possibleWeaknesses = [
          "Wait times",
          "Price point",
          "Limited menu",
          "Ambiance",
          "Service inconsistency",
          "Food quality",
        ]

        data.competitors.forEach((comp: any, index: number) => {
          // Randomly select 2 strengths and 2 weaknesses
          const strengths = [...possibleStrengths].sort(() => 0.5 - Math.random()).slice(0, 2)
          const weaknesses = [...possibleWeaknesses]
            .filter((w) => !strengths.includes(w))
            .sort(() => 0.5 - Math.random())
            .slice(0, 2)

          competitorsObj[`competitor${String.fromCharCode(65 + index)}`] = {
            ...comp,
            strengths,
            weaknesses,
          }
        })

        setCompetitors(competitorsObj)
      } else {
        // If no competitors found, use mock data
        setCompetitors({
          competitorA: {
            id: "mock-a",
            name: "Trattoria Milano",
            rating: 4.3,
            vicinity: "Nearby location",
            types: ["restaurant"],
            strengths: ["Ambiance", "Value perception"],
            weaknesses: ["Service speed", "Food consistency"],
          },
          competitorB: {
            id: "mock-b",
            name: "The Hungry Fork",
            rating: 4.1,
            vicinity: "Nearby location",
            types: ["restaurant"],
            strengths: ["Value perception", "Menu variety"],
            weaknesses: ["Ambiance", "Wait times"],
          },
          competitorC: {
            id: "mock-c",
            name: "Coastal Bites",
            rating: 4.6,
            vicinity: "Nearby location",
            types: ["restaurant"],
            strengths: ["Food quality", "Service"],
            weaknesses: ["Value perception", "Limited menu"],
          },
        })
      }

      setSearchPerformed(true)
    } catch (err) {
      console.error("Error fetching location data:", err)
      setError(err instanceof Error ? err.message : "An unknown error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const formatRevenue = (value: number) => {
    return `$${value.toLocaleString()}`
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center border-b">
        <Link className="flex items-center justify-center" href="/">
          <ArrowLeft className="mr-2 h-4 w-4" />
          <span className="font-bold text-xl">SpotOn</span>
        </Link>
      </header>
      <main className="flex-1 py-6 md:py-10">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col space-y-6">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter">Competitor Analysis & ROI Calculator</h1>
              <p className="text-muted-foreground">
                See how your restaurant compares to local competitors and calculate your potential ROI with SpotOn
              </p>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>Find Local Competitors & Calculate ROI</CardTitle>
                <CardDescription>Enter your restaurant location and monthly revenue</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSearch} className="space-y-6">
                  <div className="flex w-full items-center space-x-2">
                    <Input
                      type="text"
                      placeholder="Enter your restaurant address"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      disabled={isLoading}
                    />
                    <Button type="submit" disabled={isLoading}>
                      {isLoading ? (
                        <div className="flex items-center">
                          <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent mr-2" />
                          Searching...
                        </div>
                      ) : (
                        <>
                          <Search className="mr-2 h-4 w-4" />
                          Search
                        </>
                      )}
                    </Button>
                  </div>

                  {error && (
                    <Alert variant="destructive">
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="monthly-revenue">Monthly Revenue: {formatRevenue(monthlyRevenue)}</Label>
                    </div>
                    <Slider
                      id="monthly-revenue"
                      min={10000}
                      max={200000}
                      step={5000}
                      value={[monthlyRevenue]}
                      onValueChange={(value) => setMonthlyRevenue(value[0])}
                      className="py-4"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>$10,000</span>
                      <span>$200,000</span>
                    </div>
                  </div>
                </form>
              </CardContent>
            </Card>

            {searchPerformed && (
              <div className="space-y-6">
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-2xl">{businessInfo.name}</CardTitle>
                        <div className="flex items-center mt-1 space-x-2">
                          <Badge variant="outline">{businessInfo.category}</Badge>
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-500 mr-1" fill="currentColor" />
                            <span className="text-sm font-medium">{businessInfo.rating}</span>
                            <span className="text-sm text-muted-foreground ml-1">
                              ({businessInfo.reviewCount} reviews)
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold">${monthlyRevenue.toLocaleString()}</div>
                        <div className="text-sm text-muted-foreground">Monthly Revenue</div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="flex items-start space-x-2">
                        <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                        <span className="text-sm">{businessInfo.address}</span>
                      </div>
                      <div className="flex items-start space-x-2">
                        <Phone className="h-4 w-4 text-muted-foreground mt-0.5" />
                        <span className="text-sm">{businessInfo.phone}</span>
                      </div>
                      <div className="flex items-start space-x-2">
                        <Timer className="h-4 w-4 text-muted-foreground mt-0.5" />
                        <span className="text-sm">{businessInfo.hours}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Tabs defaultValue="reviews">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="reviews">Reviews Analysis</TabsTrigger>
                    <TabsTrigger value="menu">Menu Comparison</TabsTrigger>
                    <TabsTrigger value="pricing">Pricing Strategy</TabsTrigger>
                    <TabsTrigger value="roi">ROI Analysis</TabsTrigger>
                  </TabsList>
                  <TabsContent value="reviews" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle>Customer Review Analysis for {businessInfo.name}</CardTitle>
                        <CardDescription>
                          See how your reviews compare to competitors and identify areas for improvement
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        <div className="h-[400px] w-full">
                          <CompetitorReviewChart restaurantName={businessInfo.name} />
                        </div>

                        <div className="bg-muted p-4 rounded-lg">
                          <h3 className="text-lg font-medium mb-3">Competitive Position Summary</h3>
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Category</TableHead>
                                <TableHead>Your Rating</TableHead>
                                <TableHead>Competitor Average</TableHead>
                                <TableHead>Position</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              <TableRow>
                                <TableCell className="font-medium">Food Quality</TableCell>
                                <TableCell>4.5/5</TableCell>
                                <TableCell>4.2/5</TableCell>
                                <TableCell className="text-green-600 font-medium">
                                  <div className="flex items-center">
                                    <Check className="h-4 w-4 mr-1" />
                                    Above Average
                                  </div>
                                </TableCell>
                              </TableRow>
                              <TableRow>
                                <TableCell className="font-medium">Service</TableCell>
                                <TableCell>4.2/5</TableCell>
                                <TableCell>4.0/5</TableCell>
                                <TableCell className="text-green-600 font-medium">
                                  <div className="flex items-center">
                                    <Check className="h-4 w-4 mr-1" />
                                    Above Average
                                  </div>
                                </TableCell>
                              </TableRow>
                              <TableRow>
                                <TableCell className="font-medium">Ambiance</TableCell>
                                <TableCell>4.3/5</TableCell>
                                <TableCell>4.1/5</TableCell>
                                <TableCell className="text-green-600 font-medium">
                                  <div className="flex items-center">
                                    <Check className="h-4 w-4 mr-1" />
                                    Above Average
                                  </div>
                                </TableCell>
                              </TableRow>
                              <TableRow>
                                <TableCell className="font-medium">Value</TableCell>
                                <TableCell>3.8/5</TableCell>
                                <TableCell>4.0/5</TableCell>
                                <TableCell className="text-red-600 font-medium">
                                  <div className="flex items-center">
                                    <X className="h-4 w-4 mr-1" />
                                    Below Average
                                  </div>
                                </TableCell>
                              </TableRow>
                              <TableRow>
                                <TableCell className="font-medium">Overall</TableCell>
                                <TableCell>4.2/5</TableCell>
                                <TableCell>4.1/5</TableCell>
                                <TableCell className="text-green-600 font-medium">
                                  <div className="flex items-center">
                                    <Check className="h-4 w-4 mr-1" />
                                    Above Average
                                  </div>
                                </TableCell>
                              </TableRow>
                            </TableBody>
                          </Table>
                        </div>

                        <div className="grid gap-4 md:grid-cols-2">
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-base">Your Competitive Advantages</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <ul className="space-y-3">
                                <li className="flex items-start">
                                  <Check className="h-4 w-4 text-green-600 mt-1 mr-2 flex-shrink-0" />
                                  <span>
                                    <span className="font-medium">Food quality</span> rated higher than{" "}
                                    {competitors.competitorA?.name || "Competitor A"},{" "}
                                    {competitors.competitorB?.name || "Competitor B"}, and local average
                                  </span>
                                </li>
                                <li className="flex items-start">
                                  <Check className="h-4 w-4 text-green-600 mt-1 mr-2 flex-shrink-0" />
                                  <span>
                                    <span className="font-medium">Service speed</span> exceeds{" "}
                                    {competitors.competitorA?.name || "Competitor A"} by 15% and local average by 8%
                                  </span>
                                </li>
                                <li className="flex items-start">
                                  <Check className="h-4 w-4 text-green-600 mt-1 mr-2 flex-shrink-0" />
                                  <span>
                                    <span className="font-medium">Ambiance</span> receives better ratings than{" "}
                                    {competitors.competitorB?.name || "Competitor B"} and{" "}
                                    {competitors.competitorC?.name || "Competitor C"}
                                  </span>
                                </li>
                              </ul>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-base">Areas to Improve</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <ul className="space-y-3">
                                <li className="flex items-start">
                                  <X className="h-4 w-4 text-red-600 mt-1 mr-2 flex-shrink-0" />
                                  <span>
                                    <span className="font-medium">Value perception</span> lags behind{" "}
                                    {competitors.competitorA?.name || "Competitor A"} (4.1/5) and{" "}
                                    {competitors.competitorB?.name || "Competitor B"} (4.2/5)
                                  </span>
                                </li>
                                <li className="flex items-start">
                                  <X className="h-4 w-4 text-red-600 mt-1 mr-2 flex-shrink-0" />
                                  <span>
                                    <span className="font-medium">Waiting times</span> mentioned in 23% of negative
                                    reviews, compared to 15% for {competitors.competitorC?.name || "Competitor C"}
                                  </span>
                                </li>
                                <li className="flex items-start">
                                  <X className="h-4 w-4 text-red-600 mt-1 mr-2 flex-shrink-0" />
                                  <span>
                                    <span className="font-medium">Menu variety</span> rated lower than{" "}
                                    {competitors.competitorB?.name || "Competitor B"}, which offers 30% more options
                                  </span>
                                </li>
                              </ul>
                            </CardContent>
                          </Card>
                        </div>

                        <div className="bg-primary/5 p-4 rounded-lg">
                          <h3 className="text-lg font-medium mb-2">Competitor Snapshot</h3>
                          <div className="grid gap-4 md:grid-cols-3">
                            {Object.entries(competitors).map(([key, competitor]) => (
                              <div key={key}>
                                <h4 className="font-medium text-sm">{competitor.name}</h4>
                                <div className="mt-1 text-sm">
                                  <div className="font-medium text-xs text-muted-foreground mb-1">STRENGTHS</div>
                                  <ul className="list-disc pl-4 text-xs space-y-1">
                                    {competitor.strengths.map((strength, i) => (
                                      <li key={i}>{strength}</li>
                                    ))}
                                  </ul>
                                  <div className="font-medium text-xs text-muted-foreground mb-1 mt-2">WEAKNESSES</div>
                                  <ul className="list-disc pl-4 text-xs space-y-1">
                                    {competitor.weaknesses.map((weakness, i) => (
                                      <li key={i}>{weakness}</li>
                                    ))}
                                  </ul>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="menu" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle>Menu Analysis for {businessInfo.name}</CardTitle>
                        <CardDescription>
                          Compare your menu offerings with competitors to identify gaps and opportunities
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="h-[400px] w-full">
                          <MenuPriceComparison />
                        </div>
                        <div className="mt-6 space-y-4">
                          <h3 className="text-lg font-medium">Key Insights:</h3>
                          <ul className="list-disc pl-5 space-y-2">
                            <li>
                              Your appetizer prices are 12% higher than the local average, potentially affecting value
                              perception
                            </li>
                            <li>
                              Top competitors offer 30% more vegetarian options, representing a potential market
                              opportunity
                            </li>
                            <li>
                              Your signature dishes command a 15% premium over similar competitor offerings, indicating
                              strong brand value
                            </li>
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                  <TabsContent value="pricing" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle>Pricing Strategy Analysis for {businessInfo.name}</CardTitle>
                        <CardDescription>
                          Optimize your pricing to maximize profits while remaining competitive
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        <div className="grid gap-4 md:grid-cols-3">
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-base">Current Strategy</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold">$24.50</div>
                              <p className="text-sm text-muted-foreground">Average check size</p>
                              <div className="mt-2 text-2xl font-bold">32%</div>
                              <p className="text-sm text-muted-foreground">Average profit margin</p>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-base">Competitor Average</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold">$22.75</div>
                              <p className="text-sm text-muted-foreground">Average check size</p>
                              <div className="mt-2 text-2xl font-bold">28%</div>
                              <p className="text-sm text-muted-foreground">Average profit margin</p>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-base">Recommended</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold text-primary">$26.00</div>
                              <p className="text-sm text-muted-foreground">Optimal check size</p>
                              <div className="mt-2 text-2xl font-bold text-primary">35%</div>
                              <p className="text-sm text-muted-foreground">Projected profit margin</p>
                            </CardContent>
                          </Card>
                        </div>
                        <div className="space-y-2">
                          <h3 className="text-lg font-medium">Optimization Recommendations:</h3>
                          <ul className="list-disc pl-5 space-y-2">
                            <li>
                              Increase prices on your top 5 most ordered items by 8% to align with perceived value
                            </li>
                            <li>
                              Introduce 3 new premium menu items at a higher price point to increase average check size
                            </li>
                            <li>
                              Implement strategic combo deals to increase attachment rate of high-margin sides and
                              beverages
                            </li>
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="roi" className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle>ROI Analysis for {businessInfo.name}</CardTitle>
                        <CardDescription>See how SpotOn can improve your restaurant's profitability</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        <div className="grid gap-4 md:grid-cols-3">
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-base">Current Monthly Profit</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold">${currentProfit.toFixed(2)}</div>
                              <p className="text-sm text-muted-foreground">
                                {(100 - (foodCost + laborCost + otherExpenses)).toFixed(1)}% profit margin
                              </p>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-base">Projected Monthly Profit</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold text-primary">${projectedProfit.toFixed(2)}</div>
                              <p className="text-sm text-muted-foreground">
                                {(100 - (projectedFoodCost + projectedLaborCost + otherExpenses)).toFixed(1)}% profit
                                margin
                              </p>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-base">Monthly Savings</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="text-2xl font-bold text-primary">${monthlySavings.toFixed(2)}</div>
                              <p className="text-sm text-muted-foreground">
                                {((monthlySavings / currentProfit) * 100).toFixed(1)}% increase
                              </p>
                            </CardContent>
                          </Card>
                        </div>
                        <div className="h-[300px] w-full">
                          <ROIChart
                            currentProfit={currentProfit}
                            projectedProfit={projectedProfit}
                            investment={posInvestment}
                          />
                        </div>
                        <div className="grid gap-4 md:grid-cols-2">
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-base">Return on Investment</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                              <div>
                                <div className="text-3xl font-bold text-primary">{roi.toFixed(1)}%</div>
                                <p className="text-sm text-muted-foreground">Annual ROI</p>
                              </div>
                              <div>
                                <div className="text-xl font-bold">{paybackPeriod.toFixed(1)} months</div>
                                <p className="text-sm text-muted-foreground">Payback period</p>
                              </div>
                            </CardContent>
                          </Card>
                          <Card>
                            <CardHeader>
                              <CardTitle className="text-base">Key Benefits</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <ul className="list-disc pl-5 space-y-2">
                                <li>5% increase in revenue through improved order accuracy and upselling</li>
                                <li>2% reduction in food costs through better inventory management</li>
                                <li>3% reduction in labor costs through optimized scheduling</li>
                                <li>Improved customer experience leading to higher retention</li>
                              </ul>
                            </CardContent>
                          </Card>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>

                <Separator className="my-8" />

                <div className="space-y-6">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-bold tracking-tighter">
                      How to Transform {businessInfo.name} with SpotOn
                    </h2>
                    <p className="text-muted-foreground">
                      Based on your competitive analysis, here's how SpotOn's solutions can help you outperform your
                      competition
                    </p>
                  </div>

                  <div className="grid gap-6 md:grid-cols-3">
                    <Card>
                      <CardHeader>
                        <Heart className="h-6 w-6 mb-2 text-primary" />
                        <CardTitle>SpotOn Loyalty</CardTitle>
                        <CardDescription>Build a loyal customer base and increase repeat business</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-2">
                          <h3 className="font-medium">Addresses Your Challenges:</h3>
                          <ul className="list-disc pl-5 space-y-1 text-sm">
                            <li>Improves value perception through rewards</li>
                            <li>Increases customer return rate by 120%</li>
                            <li>Boosts average check size by 39%</li>
                          </ul>
                        </div>

                        <div className="space-y-2">
                          <h3 className="font-medium">ROI Analysis:</h3>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div>
                              <div className="font-medium">Monthly Revenue Increase:</div>
                              <div className="text-primary font-bold">${(monthlyRevenue * 0.15).toFixed(2)}</div>
                            </div>
                            <div>
                              <div className="font-medium">Annual Revenue Growth:</div>
                              <div className="text-primary font-bold">24.5%</div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Link href="/solutions/loyalty">
                          <Button className="w-full">
                            Learn More <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                        </Link>
                      </CardFooter>
                    </Card>

                    <Card>
                      <CardHeader>
                        <BarChart3 className="h-6 w-6 mb-2 text-primary" />
                        <CardTitle>SpotOn AI Reporting</CardTitle>
                        <CardDescription>Optimize operations with data-driven insights</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-2">
                          <h3 className="font-medium">Addresses Your Challenges:</h3>
                          <ul className="list-disc pl-5 space-y-1 text-sm">
                            <li>Reduces waiting times through staff optimization</li>
                            <li>Identifies menu opportunities based on competitor analysis</li>
                            <li>Optimizes pricing for better value perception</li>
                          </ul>
                        </div>

                        <div className="space-y-2">
                          <h3 className="font-medium">ROI Analysis:</h3>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div>
                              <div className="font-medium">Monthly Profit Increase:</div>
                              <div className="text-primary font-bold">${(currentProfit * 0.12).toFixed(2)}</div>
                            </div>
                            <div>
                              <div className="font-medium">Annual Profit Growth:</div>
                              <div className="text-primary font-bold">88%</div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Link href="/solutions/reporting">
                          <Button className="w-full">
                            Learn More <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                        </Link>
                      </CardFooter>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CreditCard className="h-6 w-6 mb-2 text-primary" />
                        <CardTitle>SpotOn Cash Discount</CardTitle>
                        <CardDescription>Reduce processing fees and improve profitability</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-2">
                          <h3 className="font-medium">Addresses Your Challenges:</h3>
                          <ul className="list-disc pl-5 space-y-1 text-sm">
                            <li>Improves profit margins without raising prices</li>
                            <li>Reduces processing costs by up to 75%</li>
                            <li>Encourages cash payments, reducing overall fees</li>
                          </ul>
                        </div>

                        <div className="space-y-2">
                          <h3 className="font-medium">ROI Analysis:</h3>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div>
                              <div className="font-medium">Monthly Savings:</div>
                              <div className="text-primary font-bold">${(monthlyRevenue * 0.03).toFixed(2)}</div>
                            </div>
                            <div>
                              <div className="font-medium">Processing Cost Reduction:</div>
                              <div className="text-primary font-bold">75%</div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Link href="/solutions/cash-discount">
                          <Button className="w-full">
                            Learn More <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                        </Link>
                      </CardFooter>
                    </Card>
                  </div>

                  <Card>
                    <CardHeader>
                      <CardTitle>Combined Impact of SpotOn Solutions for {businessInfo.name}</CardTitle>
                      <CardDescription>
                        Implementing all three solutions creates a powerful synergy for your business
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid gap-4 md:grid-cols-3">
                        <div className="flex flex-col items-center text-center p-4 border rounded-lg">
                          <div className="text-3xl font-bold text-primary mb-2">
                            ${(monthlyRevenue * 0.15 + currentProfit * 0.12 + monthlyRevenue * 0.03).toFixed(2)}
                          </div>
                          <p className="text-sm">Monthly revenue and profit increase</p>
                        </div>
                        <div className="flex flex-col items-center text-center p-4 border rounded-lg">
                          <div className="text-3xl font-bold text-primary mb-2">
                            ${(monthlyRevenue * 0.15 + currentProfit * 0.12 + monthlyRevenue * 0.03 * 12).toFixed(2)}
                          </div>
                          <p className="text-sm">Annual revenue and profit increase</p>
                        </div>
                        <div className="flex flex-col items-center text-center p-4 border rounded-lg">
                          <div className="text-3xl font-bold text-primary mb-2">112%</div>
                          <p className="text-sm">Return on investment</p>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full">
                        <Wallet className="mr-2 h-4 w-4" />
                        Schedule a Demo
                      </Button>
                    </CardFooter>
                  </Card>
                </div>

                <div className="mt-10 border-t pt-6">
                  <div className="text-sm text-muted-foreground">
                    <h3 className="font-medium mb-2">Disclaimers:</h3>
                    <ul className="space-y-1">
                      <li>
                        • The impact numbers presented are estimates based on industry averages and may vary based on
                        your specific business circumstances.
                      </li>
                      <li>
                        • ROI calculations are projections and not guaranteed results. Actual results may be higher or
                        lower.
                      </li>
                      <li>
                        • Competitor analysis is based on available public data and may not represent the complete
                        competitive landscape.
                      </li>
                      <li>• SpotOn solutions require proper implementation and usage to achieve optimal results.</li>
                      <li>
                        • The information provided is for illustrative purposes only and should not be considered as
                        financial advice.
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}

