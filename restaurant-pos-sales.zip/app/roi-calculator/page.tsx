"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Calculator, Download, PieChart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ROIChart } from "@/components/roi-chart"

export default function ROICalculator() {
  const [monthlyRevenue, setMonthlyRevenue] = useState(50000)
  const [foodCost, setFoodCost] = useState(35)
  const [laborCost, setLaborCost] = useState(30)
  const [otherExpenses, setOtherExpenses] = useState(20)
  const [calculationPerformed, setCalculationPerformed] = useState(false)

  const handleCalculate = (e: React.FormEvent) => {
    e.preventDefault()
    setCalculationPerformed(true)
  }

  // Calculate current profit
  const currentProfit = monthlyRevenue * (1 - (foodCost + laborCost + otherExpenses) / 100)

  // Calculate projected profit with POS (assuming 5% revenue increase, 2% food cost reduction, 3% labor cost reduction)
  const projectedRevenue = monthlyRevenue * 1.05
  const projectedFoodCost = foodCost - 2
  const projectedLaborCost = laborCost - 3
  const projectedProfit = projectedRevenue * (1 - (projectedFoodCost + projectedLaborCost + otherExpenses) / 100)

  // Calculate ROI
  const monthlySavings = projectedProfit - currentProfit
  const annualSavings = monthlySavings * 12
  const posInvestment = 10000 // Assumed POS system cost
  const roi = (annualSavings / posInvestment) * 100
  const paybackPeriod = posInvestment / monthlySavings

  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center border-b">
        <Link className="flex items-center justify-center" href="/">
          <ArrowLeft className="mr-2 h-4 w-4" />
          <span className="font-bold text-xl">SpotOn Solutions</span>
        </Link>
      </header>
      <main className="flex-1 py-6 md:py-10">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col space-y-6">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter">ROI Calculator</h1>
              <p className="text-muted-foreground">Calculate your potential return on investment with our POS system</p>
            </div>
            <Tabs defaultValue="calculator">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="calculator">Calculator</TabsTrigger>
                <TabsTrigger value="results" disabled={!calculationPerformed}>
                  Results
                </TabsTrigger>
              </TabsList>
              <TabsContent value="calculator" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Restaurant P&L Calculator</CardTitle>
                    <CardDescription>Enter your current financial information</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleCalculate} className="space-y-4">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="monthly-revenue">Monthly Revenue ($)</Label>
                          <Input
                            id="monthly-revenue"
                            type="number"
                            value={monthlyRevenue}
                            onChange={(e) => setMonthlyRevenue(Number(e.target.value))}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="food-cost">Food Cost (% of revenue)</Label>
                          <Input
                            id="food-cost"
                            type="number"
                            value={foodCost}
                            onChange={(e) => setFoodCost(Number(e.target.value))}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="labor-cost">Labor Cost (% of revenue)</Label>
                          <Input
                            id="labor-cost"
                            type="number"
                            value={laborCost}
                            onChange={(e) => setLaborCost(Number(e.target.value))}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="other-expenses">Other Expenses (% of revenue)</Label>
                          <Input
                            id="other-expenses"
                            type="number"
                            value={otherExpenses}
                            onChange={(e) => setOtherExpenses(Number(e.target.value))}
                          />
                        </div>
                      </div>
                      <Button type="submit" className="w-full">
                        <Calculator className="mr-2 h-4 w-4" />
                        Calculate ROI
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="results" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>ROI Analysis Results</CardTitle>
                    <CardDescription>
                      See how our POS system can improve your restaurant's profitability
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid gap-4 md:grid-cols-3">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base">Current Monthly Profit</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">${currentProfit.toFixed(2)}</div>
                          <p className="text-sm text-muted-foreground">
                            {(100 - (foodCost + laborCost + otherExpenses)).toFixed(1)}% profit margin
                          </p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base">Projected Monthly Profit</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold text-primary">${projectedProfit.toFixed(2)}</div>
                          <p className="text-sm text-muted-foreground">
                            {(100 - (projectedFoodCost + projectedLaborCost + otherExpenses)).toFixed(1)}% profit margin
                          </p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base">Monthly Savings</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold text-primary">${monthlySavings.toFixed(2)}</div>
                          <p className="text-sm text-muted-foreground">
                            {((monthlySavings / currentProfit) * 100).toFixed(1)}% increase
                          </p>
                        </CardContent>
                      </Card>
                    </div>
                    <div className="h-[300px] w-full">
                      <ROIChart
                        currentProfit={currentProfit}
                        projectedProfit={projectedProfit}
                        investment={posInvestment}
                      />
                    </div>
                    <div className="grid gap-4 md:grid-cols-2">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">Return on Investment</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div>
                            <div className="text-3xl font-bold text-primary">{roi.toFixed(1)}%</div>
                            <p className="text-sm text-muted-foreground">Annual ROI</p>
                          </div>
                          <div>
                            <div className="text-xl font-bold">{paybackPeriod.toFixed(1)} months</div>
                            <p className="text-sm text-muted-foreground">Payback period</p>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">Key Benefits</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="list-disc pl-5 space-y-2">
                            <li>5% increase in revenue through improved order accuracy and upselling</li>
                            <li>2% reduction in food costs through better inventory management</li>
                            <li>3% reduction in labor costs through optimized scheduling</li>
                            <li>Improved customer experience leading to higher retention</li>
                          </ul>
                        </CardContent>
                      </Card>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline">
                      <Download className="mr-2 h-4 w-4" />
                      Download Report
                    </Button>
                    <Button>
                      <PieChart className="mr-2 h-4 w-4" />
                      Schedule Demo
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  )
}

