"use client"

import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

interface CashDiscountROIChartProps {
  currentFees: number
  discountedFees: number
}

export function CashDiscountROIChart({ currentFees, discountedFees }: CashDiscountROIChartProps) {
  const data = [
    {
      name: "Current Processing Fees",
      fees: currentFees,
    },
    {
      name: "With SpotOn Cash Discount",
      fees: discountedFees,
    },
  ]

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip formatter={(value) => `$${value.toFixed(2)}`} />
        <Legend />
        <Bar dataKey="fees" name="Monthly Processing Fees" fill="#ff8042" />
      </BarChart>
    </ResponsiveContainer>
  )
}

