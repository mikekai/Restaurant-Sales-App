"use client"

import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

const data = [
  {
    category: "Appetizers",
    yours: 12.5,
    competitorA: 10.75,
    competitorB: 11.25,
    competitorC: 13.0,
    localAvg: 11.88,
  },
  {
    category: "Entrees",
    yours: 24.75,
    competitorA: 22.5,
    competitorB: 26.0,
    competitorC: 25.25,
    localAvg: 24.63,
  },
  {
    category: "Desserts",
    yours: 8.5,
    competitorA: 9.25,
    competitorB: 7.75,
    competitorC: 8.0,
    localAvg: 8.38,
  },
  {
    category: "Beverages",
    yours: 6.75,
    competitorA: 7.5,
    competitorB: 6.25,
    competitorC: 7.0,
    localAvg: 6.88,
  },
  {
    category: "Signature",
    yours: 28.5,
    competitorA: 25.0,
    competitorB: 24.75,
    competitorC: 26.0,
    localAvg: 26.06,
  },
]

export function MenuPriceComparison() {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="category" />
        <YAxis />
        <Tooltip formatter={(value) => `$${value}`} />
        <Legend />
        <Bar dataKey="yours" name="Your Restaurant" fill="#8884d8" />
        <Bar dataKey="competitorA" name="Competitor A" fill="#82ca9d" />
        <Bar dataKey="competitorB" name="Competitor B" fill="#ffc658" />
        <Bar dataKey="competitorC" name="Competitor C" fill="#ff8042" />
        <Bar dataKey="localAvg" name="Local Average" fill="#0088fe" />
      </BarChart>
    </ResponsiveContainer>
  )
}

